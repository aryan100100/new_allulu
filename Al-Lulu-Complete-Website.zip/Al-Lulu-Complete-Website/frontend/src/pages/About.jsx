import { COMPANY } from "../data/site";
import Reveal from "../components/Reveal";
import TapeReveal from "../components/TapeReveal";
import CTABand from "../components/CTABand";

const VALUES = [
  { title: "Dependable supply", text: "Businesses plan around our deliveries. We keep the everyday essentials stocked and answer with straight answers, fast." },
  { title: "The complete catalogue", text: "Corrugated, boxes, tapes, films and protection — one supplier instead of five, with quotations to match." },
  { title: "Business-to-business, always", text: "We speak procurement: quantities, sizes, specifications and formal quotations your purchasing team can work with." },
];

export default function About() {
  return (
    <div data-testid="about-page">
      <section className="grain bg-charcoal pt-32 pb-16 text-bone lg:pb-24">
        <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12">
          <h1 className="max-w-4xl font-display text-4xl font-extrabold uppercase leading-[1.02] tracking-tight sm:text-5xl lg:text-6xl">
            Complete packaging experience built around business needs.
          </h1>
          <p className="mt-6 max-w-xl text-bone/70 text-base sm:text-lg">
            Supplying packaging materials to businesses since {COMPANY.established}.
          </p>
        </div>
      </section>

      <section className="bg-bone py-16 lg:py-24">
        <div className="mx-auto grid max-w-[1400px] gap-12 px-5 sm:px-8 lg:grid-cols-12 lg:px-12">
          <div className="lg:col-span-5 lg:self-center">
            <TapeReveal>The company</TapeReveal>
            <h2 className="mt-4 font-display text-3xl font-extrabold uppercase tracking-tight sm:text-4xl">Complete packaging for your business.</h2>
          </div>
          <div className="lg:col-span-7 space-y-6 text-base leading-relaxed text-slate-700">
            <p>
              <strong className="font-semibold text-charcoal">{COMPANY.legalName}</strong> supplies packaging materials to businesses across the UAE — corrugated rolls, sheets and boxes, masking and BOPP tapes, bubble wrap, stretch films, edge protection, paper cores and strapping.
            </p>
            <p>
              Since {COMPANY.established} we have worked the way industrial customers need: a complete catalogue under one roof, practical advice on what fits the product being shipped, and formal quotations prepared properly so purchasing teams can plan with confidence.
            </p>
            <div className="grid gap-6 pt-4 sm:grid-cols-3">
              {VALUES.map((v, i) => (
                <Reveal key={v.title} delay={i * 0.07}>
                  <div className="border-t-2 border-kraft pt-4">
                    <h3 className="font-display text-base font-bold uppercase tracking-tight">{v.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-slate-600">{v.text}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-paper py-14 lg:py-20" data-testid="about-facility">
        <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12">
          <TapeReveal>Our facility</TapeReveal>
          <h2 className="mt-3 font-display text-3xl font-extrabold uppercase tracking-tight sm:text-4xl">Stocked, stacked and ready. Ready to supply.</h2>
          <p className="mt-6 max-w-3xl text-base leading-relaxed text-slate-700">
            Pallets of corrugated boxes, racks of tapes and films, and the handling equipment to load out — the stock our customers phone for is on the floor, not on order.
          </p>
          <div className="mt-10 flex max-w-3xl flex-col gap-4 border border-line bg-bone/60 p-5 rounded-sm sm:flex-row sm:items-center" data-testid="about-company-details">
            <img src="/logo.png" alt="Al Lulu Packaging official emblem" className="h-20 w-20 object-contain shrink-0" />
            <div>
              <p className="font-display text-sm font-bold uppercase tracking-wide text-charcoal">{COMPANY.legalName}</p>
              <p className="mt-1 text-sm text-slate-700">Tel: {COMPANY.phoneDisplay} | WhatsApp: {COMPANY.whatsappDisplay}</p>
            </div>
          </div>
        </div>
      </section>


      <CTABand />
    </div>
  );
}
