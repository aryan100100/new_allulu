export default function SubmissionReceipt({ receipt, showDownload = true }) {
  if (!receipt) return null;
  const download = () => {
    const bytes = Uint8Array.from(atob(receipt.pdf_base64), (char) => char.charCodeAt(0));
    const url = URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = receipt.pdf_filename;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  return (
    <div className="mt-4 max-w-sm text-center">
      <p role="status" className="text-sm text-slate-600">
        {receipt.email_status === "sent"
          ? "Your submission has been emailed to our team as a PDF."
          : "Your submission and PDF have been saved. Email delivery is pending while our mailbox is being set up."}
      </p>
      {showDownload && <button type="button" onClick={download} className="mt-4 font-mono text-[11px] uppercase tracking-[0.14em] text-kraft underline underline-offset-4">
        Download your PDF
      </button>}
    </div>
  );
}
