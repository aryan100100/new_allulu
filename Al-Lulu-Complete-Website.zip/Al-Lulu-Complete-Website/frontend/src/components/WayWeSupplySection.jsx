const STEPS = [
  {
    num: "01",
    title: "One supplier. The full range.",
    text: "Corrugated products, boxes, tapes, protective films and accessories — the catalogue our customers rely on, all under one roof.",
  },
  {
    num: "02",
    title: "Experienced in industrial supply.",
    text: "Supporting manufacturing, warehousing and logistics businesses since 2013.",
  },
  {
    num: "03",
    title: "Supply built for business.",
    text: "Quotation-based B2B supply. Tell us the product, the size and the quantity — our team responds with a formal quotation.",
  },
];


export default function WayWeSupplySection() {
  return (
    <section className="grain overflow-hidden bg-charcoal text-bone" data-testid="way-we-supply-section">
      <div className="mx-auto max-w-[1400px] px-5 py-20 sm:px-8 lg:px-12 lg:py-24">
        <p className="mb-4 font-mono text-[10px] uppercase tracking-[0.3em] text-tape">Why Al Lulu</p>
        <h2 className="font-display text-4xl font-extrabold uppercase leading-[1.02] tracking-tight sm:text-5xl">The way we supply</h2>
        <div className="mt-12 grid gap-8 lg:grid-cols-3 lg:gap-10">
          {STEPS.map((step) => (
            <div key={step.num} className="border-t border-bone/15 pt-7">
              <span className="font-mono text-xs tracking-[0.15em] text-tape">{step.num}</span>
              <h3 className="mt-4 font-display text-xl font-bold tracking-tight sm:text-2xl">{step.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-bone/60">{step.text}</p>
            </div>
          ))}
        </div>
        <p className="mt-12 border-t border-bone/15 pt-6 font-mono text-[10px] uppercase leading-relaxed tracking-[0.16em] text-bone/70">
          Dependable Supply &bull; 24h Quotation &bull; Full-Range &bull; Quality Checked
        </p>
      </div>
    </section>
  );
}
