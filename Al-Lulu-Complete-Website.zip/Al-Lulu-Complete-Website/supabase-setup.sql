-- Run once in the Supabase SQL Editor. No browser access to customer records.
create table if not exists public.quotes (
  id uuid primary key,
  created_at timestamptz not null,
  payload jsonb not null
);
create table if not exists public.contacts (
  id uuid primary key,
  created_at timestamptz not null,
  payload jsonb not null
);
alter table public.quotes enable row level security;
alter table public.contacts enable row level security;
revoke all on public.quotes, public.contacts from anon, authenticated;
grant all on public.quotes, public.contacts to service_role;
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('quotation-photos', 'quotation-photos', false, 3145728,
        array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update set public = false,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;
