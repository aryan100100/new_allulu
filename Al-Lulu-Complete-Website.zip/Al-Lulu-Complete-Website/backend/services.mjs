import { randomUUID } from 'node:crypto';
import nodemailer from 'nodemailer';
import sharp from 'sharp';
import company from './company.json' with { type: 'json' };

export class PublicError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

export function readSettings(env) {
  const required = ['SUPABASE_URL', 'SUPABASE_SECRET_KEY', 'SMTP_HOST', 'SMTP_USERNAME', 'SMTP_PASSWORD', 'SMTP_FROM', 'SUBMISSION_EMAIL_TO'];
  if (required.some(key => !env[key] || /REPLACE_WITH|your existing|your secret/i.test(env[key]))) {
    throw new PublicError(503, 'The enquiry service is not configured yet. Please contact us by phone or WhatsApp.');
  }
  if (!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(env.SUPABASE_URL)) throw new PublicError(503, 'The enquiry service needs its Supabase settings checked.');
  if (env.SUPABASE_SECRET_KEY.startsWith('sb_publishable_')) throw new PublicError(503, 'The enquiry service needs its Supabase secret key checked.');
  if (env.MAIL_DELIVERY_MODE !== 'smtp') throw new PublicError(503, 'Email delivery is not enabled yet. Please contact us by phone or WhatsApp.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(env.SUBMISSION_EMAIL_TO) || env.SUBMISSION_EMAIL_TO === 'abc@gmail.com') throw new PublicError(503, 'The receiving mailbox has not been configured.');
  return env;
}

export function createStore(env, fetchImpl = fetch) {
  async function call(method, path, options = {}) {
    const key = env.SUPABASE_SECRET_KEY;
    if (!env.SUPABASE_URL || !key) throw new Error('Storage settings missing');
    const headers = { apikey: key, ...(key.startsWith('eyJ') ? { Authorization: `Bearer ${key}` } : {}), ...options.headers };
    const response = await fetchImpl(env.SUPABASE_URL.replace(/\/$/, '') + path, {
      ...options, method, headers, signal: AbortSignal.timeout(8000),
    });
    if (!response.ok) throw new Error(`Storage operation returned ${response.status}`);
    return response;
  }
  return {
    async save(kind, data) {
      const id = randomUUID();
      await call('POST', `/rest/v1/${kind}`, { headers: { 'Content-Type': 'application/json', Prefer: 'return=minimal' },
        body: JSON.stringify({ id, created_at: data.created_at, payload: data }) });
      return id;
    },
    async list(kind, limit = 500) {
      const rows = await (await call('GET', `/rest/v1/${kind}?select=id,payload&order=created_at.desc&limit=${limit}`)).json();
      return rows.map(row => ({ ...row.payload, id: row.id }));
    },
    async upload(photo) {
      const name = randomUUID().replaceAll('-', '') + '.jpg';
      await call('POST', `/storage/v1/object/quotation-photos/${name}`, { headers: { 'Content-Type': 'image/jpeg', 'x-upsert': 'false' }, body: photo.data });
      return 'supabase:' + name;
    },
    async photo(path) {
      const name = path.replace(/^supabase:/, '');
      if (!/^[a-f0-9]{32}\.(jpg|jpeg|png|webp)$/.test(name)) throw new PublicError(404, 'Photo not available.');
      return call('GET', `/storage/v1/object/authenticated/quotation-photos/${name}`);
    },
    async check() {
      await call('GET', '/rest/v1/quotes?select=id&limit=0');
      await call('GET', '/rest/v1/contacts?select=id&limit=0');
      const bucket = await (await call('GET', '/storage/v1/bucket/quotation-photos')).json();
      if (bucket.public !== false) throw new Error('Photo bucket must be private');
    },
  };
}

export async function validatePhoto(file) {
  if (!file || typeof file.arrayBuffer !== 'function' || !file.name) return null;
  const expected = { jpg: 'jpeg', jpeg: 'jpeg', png: 'png', webp: 'webp' };
  const extension = file.name.split('.').pop().toLowerCase();
  if (/[\\/]/.test(file.name)) throw new PublicError(422, 'Choose a single photo, not a folder.');
  if (!expected[extension] || ![`image/${expected[extension]}`, 'application/octet-stream'].includes(file.type)) {
    throw new PublicError(422, 'Only JPG, PNG or WebP photos are allowed.');
  }
  if (file.size > 3 * 1024 * 1024) throw new PublicError(413, 'The photo must be 3 MB or smaller.');
  try {
    const bytes = Buffer.from(await file.arrayBuffer());
    if (!bytes.length) throw new Error('Empty photo');
    const image = sharp(bytes, { limitInputPixels: 20_000_000, animated: true });
    const metadata = await image.metadata();
    if (metadata.format !== expected[extension] || (metadata.pages || 1) !== 1) throw new Error('Invalid photo format');
    const { data, info } = await image.rotate().resize({ width: 1600, height: 1600, fit: 'inside', withoutEnlargement: true })
      .flatten({ background: '#ffffff' }).jpeg({ quality: 85 }).toBuffer({ resolveWithObject: true });
    return { data, width: info.width, height: info.height, name: file.name.slice(0, 110).replace(/\.[^.]+$/, '') + '.jpg', content_type: 'image/jpeg' };
  } catch { throw new PublicError(422, 'Please choose a readable, still photo of 20 megapixels or less.'); }
}

export function smtpTransport(env) {
  const port = Number(env.SMTP_PORT || 587);
  return nodemailer.createTransport({ host: env.SMTP_HOST, port, secure: port === 465,
    requireTLS: port !== 465, authMethod: 'LOGIN',
    auth: { user: env.SMTP_USERNAME, pass: env.SMTP_HOST === 'smtp.gmail.com' ? env.SMTP_PASSWORD.replace(/\s/g, '') : env.SMTP_PASSWORD },
    connectionTimeout: 10000, greetingTimeout: 10000, socketTimeout: 15000,
    tls: { minVersion: 'TLSv1.2' },
  });
}

export function submissionMail(env, kind, data, reference, pdf, filename) {
  const title = kind === 'quote' ? 'Quotation request' : 'Contact message';
  const labels = { company: 'Company', phone: 'Phone / WhatsApp', product: 'Product', quantity: 'Quantity',
    size_spec: 'Size / specification', delivery_location: 'Delivery location', required_date: 'Required date', notes: 'Additional requirements', message: 'Customer message' };
  return {
    from: { name: 'Al Lulu Packaging', address: env.SMTP_FROM }, to: env.SUBMISSION_EMAIL_TO,
    replyTo: data.email, subject: `Al Lulu Packaging | ${title} | ${reference}`,
    text: [`New ${title.toLowerCase()} received through the Al Lulu Packaging website.`, '', `Reference: ${reference}`, `Name: ${data.name}`, `Email: ${data.email}`,
      ...Object.entries(labels).filter(([key]) => data[key]).map(([key, label]) => `${label}: ${data[key]}`), '',
      'The complete submission is included in the attached PDF.', 'Reply to this email to contact the customer.', '', company.name, company.full_address].join('\n'),
    attachments: [{ filename, content: pdf, contentType: 'application/pdf' }],
    disableFileAccess: true, disableUrlAccess: true,
  };
}
