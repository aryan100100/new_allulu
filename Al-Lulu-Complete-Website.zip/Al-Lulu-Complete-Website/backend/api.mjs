import { timingSafeEqual } from 'node:crypto';
import jwt from 'jsonwebtoken';
import { PublicError, createStore, validatePhoto, readSettings, smtpTransport, submissionMail } from './services.mjs';
import { submissionPdf, referenceLabel } from './pdf.mjs';
import catalogue from './catalogue.json' with { type: 'json' };

const attempts = new Map();
const json = (data, status = 200) => Response.json(data, { status, headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
function same(a, b) {
  const left = Buffer.from(String(a || '')), right = Buffer.from(String(b || ''));
  return left.length === right.length && timingSafeEqual(left, right);
}
function text(value, label, { required = false, limit = 500 } = {}) {
  if (value != null && typeof value !== 'string') throw new PublicError(422, `${label} must be text.`);
  const result = String(value || '').trim();
  if (required && !result) throw new PublicError(422, `${label} is required.`);
  if (result.length > limit) throw new PublicError(422, `Please shorten ${label.toLowerCase()}.`);
  return result;
}
function authorize(request, env) {
  const token = request.headers.get('Authorization')?.replace(/^Bearer /, '');
  if (!token || !env.JWT_SECRET) throw new PublicError(401, 'Not authenticated.');
  try {
    const claims = jwt.verify(token, env.JWT_SECRET, { algorithms: ['HS256'] });
    if (claims.sub !== 'admin' || claims.type !== 'access') throw new Error('Invalid token');
  } catch { throw new PublicError(401, 'Your session has expired. Please sign in again.'); }
}
export function createHandler({ env = () => process.env, fetchImpl = fetch, sendMail, now = () => new Date() } = {}) {
  return async function handler(request, context = {}) {
    const settings = env();
    const url = new URL(request.url);
    const path = url.pathname.replace(/^\/\.netlify\/functions\/api/, '/api').replace(/\/$/, '');
    try {
      if (request.method === 'OPTIONS') return new Response(null, { status: 204 });
      if (request.method === 'GET' && path === '/api') return json({ message: 'Al Lulu Packaging API', status: 'ok', platform: 'netlify' });
      if (request.method === 'GET' && path === '/api/products') return json(catalogue);
      if (request.method === 'GET' && path.startsWith('/api/products/')) {
        const product = catalogue.products.find(product => product.id === path.split('/').pop());
        return product ? json(product) : json({ detail: 'Product not found.' }, 404);
      }
      const contentLength = Number(request.headers.get('content-length') || 0);
      if (contentLength > 3 * 1024 * 1024 + 128 * 1024) throw new PublicError(413, 'The photo must be 3 MB or smaller.');
      if (request.method === 'POST' && ['/api/quote', '/api/contact'].includes(path)) {
        const isQuote = path === '/api/quote';
        let input, file;
        try {
          if (isQuote) {
            const form = await request.formData();
            if ([...form.values()].filter(value => typeof value !== 'string' && value.size > 0).length > 1) throw new PublicError(422, 'Choose only one reference photo.');
            input = Object.fromEntries(form.entries()); file = form.get('file');
          } else input = await request.json();
        } catch (error) {
          if (error instanceof PublicError) throw error;
          throw new PublicError(422, 'The form could not be read. Please refresh and try again.');
        }
        if (!input || typeof input !== 'object' || Array.isArray(input)) throw new PublicError(422, 'Please complete the form.');
        if (input.website) throw new PublicError(422, 'Your submission could not be accepted. Please contact us directly.');
        const data = {
          name: text(input.name, 'Name', { required: true, limit: 200 }),
          email: text(input.email, 'Email', { required: true, limit: 320 }),
          phone: text(input.phone, 'Phone', { required: isQuote, limit: 100 }),
          created_at: now().toISOString(), file_name: null,
        };
        if (!/^[^\s@\r\n]+@[^\s@\r\n]+\.[^\s@\r\n]+$/.test(data.email)) throw new PublicError(422, 'A valid email address is required.');
        if (isQuote) {
          data.company = text(input.company, 'Company', { required: true, limit: 200 });
          for (const field of ['product', 'quantity', 'size_spec', 'delivery_location', 'required_date', 'notes']) {
            data[field] = text(input[field], field.replaceAll('_', ' '), { limit: field === 'notes' ? 5000 : 500 });
          }
        } else data.message = text(input.message, 'Message', { required: true, limit: 5000 });
        const photo = isQuote ? await validatePhoto(file) : null;
        readSettings(settings);
        const store = createStore(settings, fetchImpl);
        let id;
        try {
          if (photo) {
            data.file_path = await store.upload(photo); data.file_name = photo.name; data.file_content_type = photo.content_type;
          }
          id = await store.save(isQuote ? 'quotes' : 'contacts', data);
        } catch {
          console.error('Submission storage failed; check Supabase settings, tables and private bucket.');
          throw new PublicError(503, 'Could not save your enquiry. Please try again or contact us by phone or WhatsApp.');
        }
        let pdf;
        const kind = isQuote ? 'quote' : 'contact', reference = referenceLabel(kind, data.created_at, id);
        const filename = `al-lulu-${reference.toLowerCase()}.pdf`;
        try {
          pdf = await submissionPdf(kind, data, id, photo);
          const message = submissionMail(settings, kind, data, reference, pdf, filename);
          const result = sendMail ? await sendMail(message) : await smtpTransport(settings).sendMail(message);
          if (!result?.accepted?.length || result.rejected?.length) throw new Error('SMTP did not accept recipient');
        } catch {
          console.error('Submission email failed after saving enquiry; check SMTP settings and provider logs.');
          throw new PublicError(503, 'Your enquiry was saved, but email delivery failed. Please contact us by phone or WhatsApp.');
        }
        return json({ ok: true, id, email_status: 'sent', pdf_filename: filename, pdf_base64: pdf.toString('base64') });
      }
      if (path === '/api/admin/login' && request.method === 'POST') {
        let input; try { input = await request.json(); } catch { throw new PublicError(422, 'Please enter the admin passcode.'); }
        if (!settings.ADMIN_PASSCODE || !settings.JWT_SECRET || settings.JWT_SECRET.length < 32) throw new PublicError(503, 'Admin access has not been configured.');
        const ip = context.ip || 'unknown', current = Date.now();
        const failed = (attempts.get(ip) || []).filter(time => current - time < 900000);
        if (failed.length >= 5) throw new PublicError(429, 'Too many attempts. Try again in 15 minutes.');
        if (!same(input.passcode, settings.ADMIN_PASSCODE)) {
          failed.push(current); attempts.set(ip, failed);
          if (attempts.size > 1000) for (const [key, times] of attempts) if (times.every(time => current - time >= 900000)) attempts.delete(key);
          throw new PublicError(401, 'Incorrect passcode.');
        }
        attempts.delete(ip);
        return json({ token: jwt.sign({ sub: 'admin', type: 'access' }, settings.JWT_SECRET, { algorithm: 'HS256', expiresIn: '12h' }) });
      }
      if (path.startsWith('/api/admin/') || path.startsWith('/api/files/')) {
        authorize(request, settings);
        const store = createStore(settings, fetchImpl);
        if (request.method !== 'GET') throw new PublicError(405, 'Method not allowed.');
        if (path === '/api/admin/quotations') return json({ quotations: await store.list('quotes') });
        if (path === '/api/admin/contacts') return json({ contacts: await store.list('contacts') });
        if (path === '/api/admin/health') {
          readSettings(settings); await store.check();
          await smtpTransport(settings).verify();
          return json({ ok: true, storage: 'connected', smtp: 'authenticated', note: 'No email sent.' });
        }
        if (path === '/api/admin/export') {
          const type = url.searchParams.get('type') || 'quotation';
          if (!['quotation', 'contact'].includes(type)) throw new PublicError(422, 'Choose quotation or contact.');
          const rows = await store.list(type === 'quotation' ? 'quotes' : 'contacts', 1000);
          const keys = [...new Set(rows.flatMap(row => Object.keys(row)))];
          const escapeCsv = value => {
            let result = String(value ?? '');
            if (/^\s*[=+@-]/.test(result)) result = "'" + result;
            return '"' + result.replaceAll('"', '""') + '"';
          };
          const csv = [keys.map(escapeCsv).join(','), ...rows.map(row => keys.map(key => escapeCsv(row[key])).join(','))].join('\r\n');
          return new Response(csv, { headers: { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="al-lulu-${type}s.csv"`, 'Cache-Control': 'no-store' } });
        }
        if (path.startsWith('/api/files/')) {
          const response = await store.photo(decodeURIComponent(path.slice('/api/files/'.length)));
          return new Response(await response.arrayBuffer(), { headers: { 'Content-Type': response.headers.get('Content-Type') || 'application/octet-stream', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
        }
      }
      return json({ detail: 'API route not found.' }, 404);
    } catch (error) {
      if (error instanceof PublicError) return json({ detail: error.message }, error.status);
      console.error('API operation failed. Check server configuration.');
      return json({ detail: 'The enquiry service is temporarily unavailable. Please try again or contact us directly.' }, 503);
    }
  };
}
