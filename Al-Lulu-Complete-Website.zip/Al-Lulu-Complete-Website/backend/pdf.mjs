import PDFDocument from 'pdfkit';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import company from './company.json' with { type: 'json' };

export function submittedDate(value) {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Dubai', day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: true,
  }).format(new Date(value)).replace(', ', ' at ') + ' (UAE)';
}

export function referenceLabel(kind, value, id) {
  const date = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Dubai', year: 'numeric', month: '2-digit', day: '2-digit',
  }).format(new Date(value)).replaceAll('-', '');
  return `${kind === 'quote' ? 'RFQ' : 'MSG'}-${date}-${id.replaceAll('-', '').slice(-10).toUpperCase()}`;
}

export function submissionPdf(kind, data, id, photo) {
  return new Promise((resolvePdf, reject) => {
    const reference = referenceLabel(kind, data.created_at, id);
    const title = kind === 'quote' ? 'Request for Quotation' : 'Customer Enquiry';
    const doc = new PDFDocument({ size: 'A4', margins: { top: 150, left: 57, right: 57, bottom: 85 },
      bufferPages: true, info: { Title: title, Author: company.name } });
    const chunks = [];
    doc.on('data', chunk => chunks.push(chunk));
    doc.on('error', reject);
    doc.on('end', () => resolvePdf(Buffer.concat(chunks)));
    const ink = '#172024', accent = '#A05A2C', muted = '#657074', paper = '#F5F4EF';
    const left = 57, width = doc.page.width - 114;
    let y = 150;
    const ensure = (height) => {
      if (y + height > doc.page.height - 95) { doc.addPage(); y = 150; }
    };
    const textHeight = (text, w = width, size = 10) => {
      doc.font('Helvetica').fontSize(size);
      return doc.heightOfString(String(text || 'Not specified'), { width: w, lineGap: 4 });
    };
    function paragraph(text, options = {}) {
      const size = options.size || 10;
      doc.font(options.bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(size).fillColor(options.color || ink);
      for (const line of String(text || 'Not specified').split('\n')) {
        // Render in bounded pieces so long enquiries paginate without crossing the footer.
        const words = line.split(/\s+/);
        let part = '';
        for (const word of words) {
          const next = part ? part + ' ' + word : word;
          if (doc.widthOfString(next) > width && part) {
            ensure(size + 6); doc.text(part, left, y, { width, lineBreak: false }); y += size + 6; part = word;
          } else part = next;
        }
        ensure(size + 6); doc.text(part, left, y, { width });
        y = Math.max(y + size + 6, doc.y + 3);
      }
    }
    function section(label) {
      ensure(65); y += 18;
      doc.font('Helvetica-Bold').fontSize(10).fillColor(accent).text(label, left, y, { width }); y += 25;
    }
    function grid(rows) {
      for (const row of rows) {
        const col = width / 2, cellWidth = col - 24;
        const heights = row.map(([, value]) => textHeight(value, cellWidth));
        const height = Math.max(...heights, 15) + 42;
        ensure(height + 6);
        doc.rect(left, y, width, height).fill(paper);
        row.forEach(([label, value], index) => {
          const x = left + index * col + 12;
          doc.font('Helvetica-Bold').fontSize(7.5).fillColor(muted).text(label.toUpperCase(), x, y + 10, { width: cellWidth });
          doc.font('Helvetica').fontSize(10).fillColor(ink).text(String(value || 'Not specified'), x, y + 27, { width: cellWidth, lineGap: 4 });
        });
        y += height + 2;
      }
    }
    try {
      doc.font('Helvetica-Bold').fontSize(25).fillColor(ink).text(title, left, y, { width }); y = doc.y + 7;
      doc.font('Helvetica').fontSize(8).fillColor(muted).text(kind === 'quote' ? 'Packaging requirements submitted for review' : 'Website contact message', left, y, { width }); y = doc.y + 20;
      grid([[['Reference', reference], ['Submitted', submittedDate(data.created_at)]]]);
      section('01  CUSTOMER DETAILS');
      grid([[['Contact name', data.name], ['Company', data.company || 'Website enquiry']],
        [['Email address', data.email], ['Phone / WhatsApp', data.phone || 'Not provided']]]);
      if (kind === 'quote') {
        section('02  PACKAGING REQUIREMENTS');
        grid([[['Product / category', data.product], ['Quantity', data.quantity]],
          [['Size / specification', data.size_spec], ['Delivery location', data.delivery_location]]]);
        if (data.required_date) grid([[['Required date', data.required_date], ['Delivery terms', 'To be confirmed']]]);
        if (data.notes) { section('03  ADDITIONAL REQUIREMENTS'); paragraph(data.notes); }
        if (photo) {
          ensure(240); section('REFERENCE PHOTO');
          doc.image(photo.data, left, y, { fit: [width, 200], align: 'left' });
          y += Math.min(200, width * photo.height / photo.width) + 12;
        }
        section('NEXT STEP');
        paragraph('Our team will review these requirements and prepare a formal quotation. Pricing, availability and delivery terms will be confirmed in that quotation.', { size: 8, color: muted });
      } else { section('02  MESSAGE'); paragraph(data.message); }

      let logo;
      try { logo = readFileSync(resolve(process.cwd(), 'backend/assets/logo.png')); } catch { /* Missing branding must not discard an enquiry. */ }
      const range = doc.bufferedPageRange();
      const bottom = doc.page.margins.bottom;
      for (let index = range.start; index < range.start + range.count; index++) {
        doc.switchToPage(index); doc.page.margins.bottom = 0;
        doc.rect(0, 0, doc.page.width, 122).fill(paper);
        if (logo) doc.image(logo, left, 27, { fit: [66, 66] });
        doc.font('Helvetica-Bold').fontSize(14).fillColor(ink).text('AL LULU PACKAGING', 138, 32, { width: width - 81 });
        doc.font('Helvetica').fontSize(7.5).text(company.legal_name, 138, 55, { width: width - 81 });
        doc.fillColor(muted).text(company.full_address, 138, 72, { width: width - 81 });
        doc.text('Established 2013', 138, 90, { width: width - 81 });
        doc.moveTo(left, 122).lineTo(left + width, 122).lineWidth(1.5).stroke(accent);
        doc.moveTo(left, doc.page.height - 65).lineTo(left + width, doc.page.height - 65).lineWidth(0.5).stroke('#DEE2DF');
        doc.fontSize(7.2).fillColor(muted).text(`Tel: ${company.phone_intl} | WhatsApp: ${company.whatsapp} | ${company.email_primary}`, left, doc.page.height - 49, { width });
        doc.text(reference, left, doc.page.height - 34, { width: width - 65 });
        doc.text(`Page ${index + 1}`, left + width - 60, doc.page.height - 34, { width: 60, align: 'right' });
        doc.page.margins.bottom = bottom;
      }
      doc.end();
    } catch (error) { doc.destroy(); reject(error); }
  });
}
