import { readSettings, createStore, smtpTransport } from '../backend/services.mjs';

// Read-only checks: never submit an enquiry, upload a photo, or send an email.
try {
  const settings = readSettings(process.env);
  await createStore(settings).check();
  console.log('Supabase: both enquiry tables are accessible and the photo bucket is private.');
  await smtpTransport(settings).verify();
  console.log('Gmail: SMTP authentication succeeded. No email was sent.');
} catch (error) {
  console.error(error.status ? error.message : 'Service check failed. Check the Supabase key/schema and Gmail app password; no email was sent.');
  process.exitCode = 1;
}
