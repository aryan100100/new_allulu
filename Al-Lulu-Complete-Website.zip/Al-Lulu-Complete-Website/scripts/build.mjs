import { spawnSync } from 'node:child_process';
import './prepare-functions.mjs';

for (const args of [['ci', '--legacy-peer-deps', '--include=dev'], ['run', 'build']]) {
  const result = spawnSync('npm', args, {
    cwd: new URL('../frontend/', import.meta.url), stdio: 'inherit',
    env: { ...process.env, REACT_APP_BACKEND_URL: '' },
  });
  if (result.status !== 0) process.exit(result.status || 1);
}
