import { spawnSync } from 'node:child_process';
import { cpSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';

// CLI deployments built on a Mac must also contain Netlify's Linux image decoder.
// Install in a separate directory so local photo processing keeps working too.
const root = resolve(import.meta.dirname, '..');
const target = resolve(root, '.netlify/linux-runtime');
const result = spawnSync('npm', ['install', '--prefix', target, '--no-package-lock',
  '--ignore-scripts', '--no-audit', '--no-fund', '--os=linux', '--cpu=x64',
  '--libc=glibc', 'sharp@0.35.5'], { cwd: root, stdio: 'inherit' });
if (result.status !== 0) process.exit(result.status || 1);
mkdirSync(resolve(root, 'node_modules/@img'), { recursive: true });
for (const name of ['sharp-linux-x64', 'sharp-libvips-linux-x64']) {
  cpSync(resolve(target, 'node_modules/@img', name), resolve(root, 'node_modules/@img', name), { recursive: true });
}
console.log('Netlify Linux photo processing is prepared.');
