import { createHandler } from '../../backend/api.mjs';

export default createHandler();

export const config = {
  rateLimit: { windowLimit: 30, windowSize: 60, aggregateBy: ['ip', 'domain'] },
};
