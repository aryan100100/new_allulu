import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import nodemailer from 'nodemailer';
import sharp from 'sharp';
import { createHandler } from '../backend/api.mjs';
import { submittedDate } from '../backend/pdf.mjs';

const settings = { SUPABASE_URL: 'https://example.supabase.co', SUPABASE_SECRET_KEY: 'sb_secret_test_only',
  SMTP_HOST: 'smtp.gmail.com', SMTP_PORT: '587', SMTP_USERNAME: 'allulupackaging01@gmail.com',
  SMTP_FROM: 'allulupackaging01@gmail.com', SMTP_PASSWORD: 'not-a-real-password', MAIL_DELIVERY_MODE: 'smtp',
  SUBMISSION_EMAIL_TO: 'lulupackaging@gmail.com', ADMIN_PASSCODE: 'test-only-passcode', JWT_SECRET: 'test-only-signing-secret-longer-than-32-characters' };

function harness({ storageFailure = false, sendingFailure = false, rejected = false, env = {} } = {}) {
  const rows = { quotes: [], contacts: [] }, objects = new Map(), mail = [], calls = [];
  const handler = createHandler({ env: () => ({ ...settings, ...env }), now: () => new Date('2026-10-16T08:30:00Z'),
    fetchImpl: async (url, options) => {
      calls.push({ url, ...options });
      assert.equal(options.headers.apikey, (env.SUPABASE_SECRET_KEY || settings.SUPABASE_SECRET_KEY));
      if (storageFailure) return new Response('Unavailable', { status: 503 });
      const pathname = new URL(url).pathname;
      if (pathname.includes('/rest/v1/')) {
        const table = pathname.split('/').pop();
        if (options.method === 'POST') { rows[table].push(JSON.parse(options.body)); return new Response(null, { status: 201 }); }
        return Response.json(rows[table]);
      }
      if (pathname.includes('/bucket/')) return Response.json({ public: false });
      const name = pathname.split('/').pop();
      if (options.method === 'POST') { objects.set(name, options.body); return Response.json({ ok: true }); }
      return new Response(objects.get(name), { headers: { 'Content-Type': 'image/jpeg' } });
    },
    sendMail: async message => {
      if (sendingFailure) throw new Error('Fake SMTP failure');
      mail.push(message);
      return { accepted: rejected ? [] : [message.to], rejected: rejected ? [message.to] : [] };
    },
  });
  return { handler, rows, objects, mail, calls };
}
const contact = (values = {}) => new Request('https://example.netlify.app/api/contact', { method: 'POST',
  headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'Local Test Customer', email: 'customer@example.com', phone: '0500000000', message: 'Local test only. Please quote the items listed.', ...values }) });
function quote({ file, values = {}, route = '/api/quote' } = {}) {
  const data = new FormData();
  for (const [key, value] of Object.entries({ name: 'Local Test Customer', company: 'Example Company', email: 'customer@example.com', phone: '0500000000', product: 'Corrugated Boxes', quantity: '500', size_spec: '40 x 30 x 25 cm', delivery_location: 'Customer delivery address', notes: 'Local test only. No email will be sent.', ...values })) data.set(key, value);
  if (file) data.set('file', file);
  return new Request('https://example.netlify.app' + route, { method: 'POST', body: data });
}
async function png() { return sharp({ create: { width: 400, height: 250, channels: 3, background: '#A05A2C' } }).png().toBuffer(); }

test('both forms save records and return the exact PDF attached to one email', async () => {
  const h = harness();
  for (const [kind, request] of [['quote', quote()], ['contact', contact()]]) {
    const response = await h.handler(request), result = await response.json();
    assert.equal(response.status, 200); assert.equal(result.ok, true); assert.equal(result.email_status, 'sent');
    const message = h.mail.at(-1);
    assert.equal(message.from.address, settings.SMTP_FROM); assert.equal(message.to, settings.SUBMISSION_EMAIL_TO);
    assert.equal(message.replyTo, 'customer@example.com'); assert.equal(message.attachments.length, 1);
    assert.equal(message.attachments[0].contentType, 'application/pdf');
    assert.equal(message.attachments[0].content.toString('base64'), result.pdf_base64);
    assert.equal(Buffer.from(result.pdf_base64, 'base64').subarray(0, 4).toString(), '%PDF');
    assert.equal(h.rows[kind === 'quote' ? 'quotes' : 'contacts'].length, 1);
    assert.ok(!JSON.stringify(result).includes(settings.SUPABASE_SECRET_KEY));
    const eml = await nodemailer.createTransport({ streamTransport: true, buffer: true }).sendMail(message);
    await mkdir('output/test-artifacts', { recursive: true });
    await writeFile(`output/test-artifacts/${kind}.pdf`, message.attachments[0].content);
    await writeFile(`output/test-artifacts/${kind}.eml`, eml.message);
  }
});

test('a reference photo is validated, saved privately, and embedded only in the PDF', async () => {
  const h = harness(), photo = new File([await png()], 'customer-reference.png', { type: 'image/png' });
  const response = await h.handler(quote({ file: photo })), result = await response.json();
  assert.equal(response.status, 200); assert.equal(h.objects.size, 1);
  assert.match(h.rows.quotes[0].payload.file_path, /^supabase:/);
  assert.equal(h.mail[0].attachments.length, 1);
  const pdf = Buffer.from(result.pdf_base64, 'base64');
  assert.match(pdf.toString('latin1'), /\/Subtype \/Image/);
  assert.doesNotMatch(h.mail[0].text, /Customer attachment|customer-reference|supabase:/);
  await writeFile('output/test-artifacts/quote-photo.pdf', pdf);
});

test('PDF, fake image, folder and oversized upload are rejected before persistence or email', async () => {
  const cases = [new File(['%PDF-1.4'], 'file.pdf', { type: 'application/pdf' }),
    new File(['%PDF-1.4'], 'fake.png', { type: 'image/png' }),
    new File([await png()], 'folder/photo.png', { type: 'image/png' }),
    new File([Buffer.alloc(3 * 1024 * 1024 + 1)], 'huge.jpg', { type: 'image/jpeg' })];
  for (const file of cases) {
    const h = harness(), response = await h.handler(quote({ file }));
    assert.ok([413, 422].includes(response.status)); assert.equal(h.calls.length, 0); assert.equal(h.mail.length, 0);
  }
});

test('required fields, bad email and honeypot fail before storage and sending', async () => {
  for (const request of [quote({ values: { company: '' } }), quote({ values: { phone: '' } }), contact({ email: 'invalid' }), contact({ message: '' }), contact({ website: 'spam.example' })]) {
    const h = harness(), response = await h.handler(request);
    assert.equal(response.status, 422); assert.equal(h.calls.length, 0); assert.equal(h.mail.length, 0);
  }
});

test('both forms report a storage failure and never send', async () => {
  for (const request of [quote(), contact()]) {
    const h = harness({ storageFailure: true }), response = await h.handler(request);
    assert.equal(response.status, 503); assert.equal(h.mail.length, 0); assert.match((await response.json()).detail, /Could not save/);
  }
});

test('SMTP errors or rejected recipients cannot produce false success on either form', async () => {
  for (const option of [{ sendingFailure: true }, { rejected: true }]) for (const request of [quote(), contact()]) {
    const h = harness(option), response = await h.handler(request);
    assert.equal(response.status, 503); assert.match((await response.json()).detail, /saved, but email delivery failed/);
    assert.equal(h.rows.quotes.length + h.rows.contacts.length, 1);
  }
});

test('missing credentials, preview mode and public-only keys fail closed', async () => {
  for (const env of [{ SMTP_PASSWORD: '' }, { SUPABASE_SECRET_KEY: '' }, { MAIL_DELIVERY_MODE: 'preview' }, { SUPABASE_SECRET_KEY: 'sb_publishable_wrong' }]) {
    const h = harness({ env }), response = await h.handler(contact());
    assert.equal(response.status, 503); assert.equal(h.calls.length, 0); assert.equal(h.mail.length, 0);
  }
});

test('legacy Supabase service keys use the compatible authorization header', async () => {
  const h = harness({ env: { SUPABASE_SECRET_KEY: 'eyJtest.legacy.key' } });
  assert.equal((await h.handler(contact())).status, 200);
  assert.equal(h.calls[0].headers.Authorization, 'Bearer eyJtest.legacy.key');
});

test('function-prefix routing reaches the real API, never the React fallback', async () => {
  const h = harness();
  assert.equal((await h.handler(quote({ route: '/.netlify/functions/api/quote' }))).status, 200);
  assert.equal((await h.handler(new Request('https://example.netlify.app/api/'))).status, 200);
  assert.equal((await h.handler(new Request('https://example.netlify.app/api/not-a-route'))).status, 404);
});

test('admin login protects both inboxes, exports and customer photo downloads', async () => {
  const h = harness();
  for (const route of ['/api/admin/contacts', '/api/admin/quotations', '/api/admin/export', '/api/files/supabase:photo.jpg']) {
    assert.equal((await h.handler(new Request('https://example.netlify.app' + route))).status, 401);
  }
  const login = await h.handler(new Request('https://example.netlify.app/api/admin/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ passcode: settings.ADMIN_PASSCODE }) }));
  const token = (await login.json()).token, headers = { Authorization: 'Bearer ' + token };
  await h.handler(contact({ name: '=SUM(1,1)' }));
  const file = new File([await png()], 'photo.png', { type: 'image/png' });
  await h.handler(quote({ file }));
  assert.equal((await h.handler(new Request('https://example.netlify.app/api/admin/contacts', { headers }))).status, 200);
  const savedPath = h.rows.quotes[0].payload.file_path;
  const photo = await h.handler(new Request('https://example.netlify.app/api/files/' + savedPath, { headers }));
  assert.equal(photo.status, 200); assert.equal(photo.headers.get('Content-Type'), 'image/jpeg');
  const csv = await h.handler(new Request('https://example.netlify.app/api/admin/export?type=contact', { headers }));
  assert.equal(csv.status, 200); assert.match(await csv.text(), /'=SUM/);
});

test('overlong messages are rejected and long valid messages produce PDFs', async () => {
  const h = harness();
  assert.equal((await h.handler(contact({ message: 'a'.repeat(5001) }))).status, 422);
  const response = await h.handler(contact({ message: 'A detailed customer enquiry. '.repeat(130) }));
  assert.equal(response.status, 200);
});

test('submission dates are readable in UAE time', () => {
  assert.match(submittedDate('2026-10-16T08:30:00Z'), /16 Oct 2026 at 12:30 pm \(UAE\)/i);
});
