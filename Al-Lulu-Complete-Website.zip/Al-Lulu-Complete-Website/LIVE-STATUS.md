# Deployment record — 16 October 2026

Public website: https://al-lulu-packaging.netlify.app

Company dashboard: https://app.netlify.com/projects/al-lulu-packaging

Owner workspace: Al-lulu (`al-lulu`), company account `allulupackaging01@gmail.com`, Free plan.

Both the frontend and the enquiry backend are deployed in this project. Supabase remains the database/private photo storage; Gmail remains the sending service. No custom domain has been purchased or connected.

Verified on the live deployment:

- Home, About, Products, Contact and Request a Quote return successfully without visitor login.
- `/api/` runs the Netlify backend.
- Empty quotation/contact requests reach server validation and return the expected JSON error. They create no records and send no emails.
- The admin inbox rejects unauthenticated requests; the existing passcode signs in successfully.
- The authenticated readiness check connects to both Supabase tables and the private photo bucket, and successfully authenticates with Gmail from Netlify. It sends no email.

Local verification: all 12 backend tests pass, including both complete submission paths using mock storage/mail, SMTP/storage failure handling, photo validation, embedded-photo PDFs, private inbox access and CSV exports. The exact PDFs supplied as email attachments are checked against the form response. PDFs were rendered and visually reviewed. The function archive includes the company logo, PDF fonts and Linux photo decoder.

Sending account: `allulupackaging01@gmail.com`.

Receiving account: `lulupackaging@gmail.com`.

After the owner explicitly authorized testing, exactly one real contact test (MSG-20261016-70A27A9607) and one quotation test (RFQ-20261016-AF45BD0516) were submitted through the live Netlify API. Both returned HTTP 200 and email_status sent after Gmail accepted the PDF email to lulupackaging@gmail.com. The quotation included a catalogue reference photo. Both records were verified in the private inbox. No additional test emails were sent. Actual inbox receipt and spam-folder placement cannot be confirmed without the recipient checking the mailbox; SMTP acceptance does not guarantee primary-inbox delivery.

The React build reports advisories in its existing dependency tree. The new backend's production dependency audit was clean during preparation. This verification is not a full security audit of the entire website.

For future deployments, use this folder and `npx netlify deploy --build --prod`. Do not deploy the older Vercel export to this Netlify project. See START-HERE.md for domain connection and maintenance.
