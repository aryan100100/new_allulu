# Al Lulu Packaging — Netlify handover

This folder contains the complete website and the backend for both enquiry forms. Deploy this folder as one Netlify project. Keep the company account as the owner. No domain is needed for the initial launch; Netlify provides an HTTPS address.

The initial deployment is live at https://al-lulu-packaging.netlify.app. Its dashboard is https://app.netlify.com/projects/al-lulu-packaging. See LIVE-STATUS.md for the checks performed and their limits. On this computer the folder is already linked; use `npx netlify deploy --build --prod` for updates. The first-deployment instructions below are for restoring or creating a project, not for routine updates.

## What runs where

- Netlify serves the React website and runs the server-side enquiry function.
- Supabase stores quotation requests, contact messages and private reference photos.
- Gmail sends one PDF per submission from `allulupackaging01@gmail.com` to `lulupackaging@gmail.com`. The customer's email is the reply-to address.
- Quote photos are included inside the PDF. Contact confirmations do not offer a PDF download.

The old Vercel deployments are independent. The Netlify build uses `/api` on its own website address.

## First deployment from this folder

Use Node.js 22 or 24. Open Terminal in this folder, then:

```sh
npm ci
npx netlify login
npx netlify sites:create
```

Choose the company workspace and a project name. Then import the existing private settings file (it is stored outside this shareable folder):

```sh
npx netlify env:import ../netlify-private.env
npm test
npx netlify deploy --build --prod
```

If restoring on another computer, create a private settings file using `.env.example` as the list of required names and fill in the existing Supabase/Gmail/admin values. Do not put passwords or secret keys in React settings, upload them as public files, commit them, or send them with this source package. Use Netlify Project configuration → Environment variables to enter or change them instead. Redeploy after changing settings.

The build command prepares the Linux photo decoder even when deploying from a Mac. Always include `--build` when publishing from Terminal. Dragging only `frontend/build` into Netlify omits the backend and will break the forms.

## Build settings

Keep `netlify.toml` in this folder. Base directory is this folder; build command is `npm run build`; publish directory is `frontend/build`; functions directory is `netlify/functions`. Do not select `frontend` as the project root. The build automatically installs and builds the frontend.

For Git-based deployments later, import this entire folder as the repository root. Netlify can read its settings automatically.

## Checks after publishing

1. Open the Netlify address and reload `/about`, `/products`, `/contact` and `/request-quote` directly.
2. Open `/api/`; it should return JSON with `platform: netlify`.
3. Open `/admin` and use the existing private passcode. The backend's authenticated `/api/admin/health` check verifies Supabase and Gmail authentication without sending an email.
4. A real submission sends mail to the receiving company inbox. Do not submit tests there without the mailbox owner's authorization. Inbox placement is controlled by the email provider; SMTP acceptance does not prove receipt or primary-inbox placement.

For a local connection check, copy private settings to `.env` in this folder and run `npm run verify`. This reads the Supabase tables/bucket and verifies Gmail authentication; it creates no enquiry and sends no mail. `npm start` previews the built site and real backend locally; submitting its forms DOES send real mail when `.env` is configured.

## Storage and email

Keep the existing Supabase project active. The included `supabase-setup.sql` is only for restoring the database/bucket in a new project; the current project is already configured. Use a Supabase secret/service-role key, never a browser publishable key. The photo bucket must remain private. JPG, PNG and WebP reference photos are limited to 3 MB.

Keep two-step verification enabled on the sending Gmail account and retain its app password privately. Revoking/changing that password requires updating `SMTP_PASSWORD` in Netlify and redeploying. Gmail and Netlify both have usage limits; hosting does not make email unlimited. A form shows success only after storage succeeds and Gmail accepts its PDF message.

## Add the domain later

Buy the domain in the company-controlled registrar account. In this Netlify project's Domain management, add the purchased domain, then follow the exact DNS records Netlify shows. Add both the bare domain and `www`, choose one as the primary address, and wait for DNS and HTTPS to become active. Keep any email-related DNS records already in use. Forms continue to use the same website address automatically; no frontend API URL change is needed.

## Maintenance

Keep Netlify, Supabase, Gmail recovery details and the registrar accessible to the company. Review usage limits and paused-project notices. The existing React build tools report dependency advisories and should be modernized as a separate maintenance task; do not run a forced dependency upgrade during a client deployment without testing it. Local tests use fake storage and locally generated email files; they send no mail.
